def receive():
    return '收到来自 XXX 的短信'