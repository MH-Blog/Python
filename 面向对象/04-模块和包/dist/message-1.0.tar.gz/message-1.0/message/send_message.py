def send(message):
    print("正在发送 '%s'..."%message)